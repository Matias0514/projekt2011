package org.example;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

/*W jednym z poprzednich zadań należało stworzyć klasę Drink, która reprezentowała drinka złożonego z 3 składników.
Tym razem napisz to samo zadanie, ale w taki sposób,
aby drink mógł zawierać dowolną ilość składników,
a same informacje o składnikach powinny być wczytywane od użytkownika.
Pełna treść zadania:
Zdefiniuj klasę Barman, która posiada metodę createDrink która tworzy drinka
z dowolną ilością składników podanych przez użytkownika. W wyniku metoda powinna zwracać
obiekt typu Drink z informacjami o składnikach danego drinka. Każdy składnik w klasie Drink
powinien być reprezentowany przez klasę Ingredient, która przechowuje nazwę oraz ilość danego składnika.
Dane wczytaj od użytkownika korzystającego z aplikacji.
Klasa Barman powinna także posiadać metodę printDrink,
która przyjmuje jako parametr obiekt typu Drink i wyświetla o nim informacje. */
public class Barman extends Ingredient {
    int a = 1;
    List<String> drink = new ArrayList<>();

    public List<String> getDrink() {
        return drink;
    }

    public void setDrink(List<String> drink) {
        this.drink = drink;
    }

    public List<String> createDrink(List<String> drink){
        Scanner scan = new Scanner(System.in);
        String nazwaSkladnika = null;
        while(a != 0){
            System.out.println("Podaj składnik 1 - 6 (1-Gin,2-Wódka,3-Malibu,4-Sok z cytryny,5-Cola,6-Whiskey) :");
            int ktoryskladnik = Integer.parseInt(scan.nextLine());
            if(ktoryskladnik == 1){
                nazwaSkladnika = skladnik1;
            }
            if(ktoryskladnik == 2){
                nazwaSkladnika = skladnik2;
            }
            if(ktoryskladnik == 3){
                nazwaSkladnika = skladnik3;
            }
            if(ktoryskladnik == 4){
                nazwaSkladnika = skladnik4;
            }
            if(ktoryskladnik == 5){
                nazwaSkladnika = skladnik5;
            }
            if(ktoryskladnik == 6){
                nazwaSkladnika = skladnik6;
            }
            if(ktoryskladnik > 6 || ktoryskladnik < 1){
                nazwaSkladnika = "Brak";
            }
            System.out.println("Ilość tego składnika:");
            String iloscSkladnika = scan.nextLine();
            drink.add(nazwaSkladnika);
            drink.add(iloscSkladnika);
            System.out.println("Czy chcesz dalej dodać składniki 1 - TAK , 0 - NIE:");
            a = Integer.parseInt(scan.nextLine());
        }
        return drink;
    }
    public void printDrink(List<String> drink){
        System.out.println(drink);
    }
    public boolean checkDrink(boolean empty,List<String> drink){
        if(drink.isEmpty() == true){
            empty = false;
        }
        else{
            empty = true;
        }
        return empty;
    }
}
