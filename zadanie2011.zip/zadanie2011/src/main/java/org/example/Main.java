package org.example;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Barman nowydrink = new Barman();
        List<String> ndrink = new ArrayList<>();
        nowydrink.createDrink(ndrink);
        nowydrink.printDrink(ndrink);
    }
}