package pl.devfoundry.testing;

import org.example.Barman;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class BarmanTest {
    @Test
    void myTest1() {
        Barman newDrink = new Barman();
        List<String> testDrink = new ArrayList<>();
        newDrink.printDrink(testDrink);
    }
    @Test
    void myTest() {
        Barman newDrink = new Barman();
        List<String> testDrink = new ArrayList<>();
        boolean czy = false;
        assertTrue(newDrink.checkDrink(czy, testDrink),"Drink jest pusty");
    }
}
